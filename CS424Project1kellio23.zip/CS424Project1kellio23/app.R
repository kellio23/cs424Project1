#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(ggplot2)
library(lubridate)
library(DT)
library(jpeg)
library(grid)
library(leaflet)
library(scales)
library(readr)

# TODO
# Add ability to add and remove tables/graphs. ex view just one or all of them
# sort tables better
# add ability to turn on/off tables
# General GUI cleaning
# change start screen to be included in dashboard -- do at same time as adding and turning off graphs/tables


# Checkpoint 1 - break file into 5MB chunks

# Import all the data in the csv
#rawData <- read.table(file = "CTA_-_Ridership_-__L__Station_Entries_-_Daily_Totals.csv", sep = ',', header = TRUE, quote = "")
#uicHalstedRawData <- read.table(file = "uicHalsted.csv", sep = ',', header = TRUE)

#View(rawData)
#View(uicHalstedRawData)
# Store in frame
#allDataFrame <- data.frame(rawData)
#uicHalstedFrame <- data.frame(uicHalstedRawData)

# old but keep for ohare
#allDataFrame$rides <- as.numeric(as.character(allDataFrame$rides))
#

# old but keep for ohare
#allDataFrame$yearNumber <- format(as.Date(allDataFrame$date, format="%m/%d/%Y"),"%Y")

# Get just the uic halsted data old keep for ohare
#uicHalstedFrame = split(allDataFrame, allDataFrame$station_id)[['40350']]
#

# Write frame to csv so its under the 5MB limit old keep for ohare
#write.csv(uicHalstedFrame,"C:/Users/guagu/OneDrive/Documents/CS424Project1kellio23/uicHalsted.csv", row.names = TRUE)
#

#View(uicHalstedFrame)
#View(uicHalstedFrame2) has x column when 1st doesnt, shouldnt matter




#### code above is left for adding more stops at a later point, only works locally
#### since the file limit for shiny is 5mb

uicHalstedRawData <- read.table(file = "uicHalsted.csv", sep = ',', header = TRUE)
uicHalstedFrame <- data.frame(uicHalstedRawData)


# Checkpoint 2 - use lubridate to convert date info to more useable form
# date - 12/22/2017
uicHalstedFrame$date <- mdy(uicHalstedFrame$date)
uicHalstedFrame$monthNumber <- month(uicHalstedFrame$date)
uicHalstedFrame$dayNumber <- day(uicHalstedFrame$date)
uicHalstedFrame$dayOfWeek <- weekdays(uicHalstedFrame$date)
dayOrder <- c('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')



#View(uicHalstedFrame)

# Checkpoint 3 - Create interactive visualization in R
#listNames <- c(colnames(allData))
#listNamesGood <- listNames[listNames != "Hour" & listNames != "newDate"]
stationNames <- c("UIC Halsted")
totalAcrossYearsOptions <- c("Off", "Graph")
totalYearOptions <- c("Off", "Graph Only", "Table Only","Both")
dailyYearOptions <- c("Off","Graph Only", "Table Only","Both")
monthlyYearOptions <- c("Off","Graph Only", "Table Only","Both")
years<-c(2001:2021)

ui <- dashboardPage(
  dashboardHeader(title = "CTA Daily Rider Data"),
  dashboardSidebar(disable = FALSE, collapsed = FALSE,
                   
                   sidebarMenu(
                     menuItem("Start Page", tabName = "startPage", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("Dashboard", tabName = "dashboard", icon = NULL),
                     menuItem("About this project", tabName = "projInfo", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL),
                     menuItem("", tabName = "cheapBlankSpace", icon = NULL)),
                   
                   selectInput("Year", "Select the year to visualize", years, selected = 2021),
                   selectInput("Stop", "Select the Stop", stationNames, selected = "UIC Halsted"),
                   selectInput("totalAcrossYears", "Total across Years", totalAcrossYearsOptions, selected = "Graph"),
                   selectInput("totalYear", "Total in Year", totalYearOptions, selected = "Off"),
                   selectInput("dailyYear", "Daily in Year", dailyYearOptions, selected = "Off"),
                   selectInput("monthlyYear", "Monthly in Year", monthlyYearOptions, selected = "Off")
                   
  ),
  dashboardBody(
    fluidRow(
        
      

          # whatever is in here always shows up despite tab change?
      
    ),
    
    tabItems(
      
      tabItem(tabName = "startPage",
              h2("Welcome to my CS 424 Project 1"),
              h2("To get started, press the dashboard option on the sidebar"),
              column(10,
                     fluidRow(
                       box(title = "Total Riders per Year", solidHeader = TRUE, status = "primary", width = 20,
                           plotOutput("startGraph", height = 350)
                       )
                     )
                     
              )
              
      ),
      # First tab content monthlyRiderTable dailyYearlyRiderTable
      tabItem(tabName = "dashboard",
              
              
              column(6,
                     
                    # monthly("monthly")
                     uiOutput("monthly")
                     
                     # fluidRow(
                     #   box( title = "Total Rides per Month", solidHeader = TRUE, status = "primary", width = 8,
                     #        #ggplot(uicHalstedFrame, aes(x=years, y=rides)) + geom_bar(stat = "identity")
                     #        #ggplot(uicHalstedFrame, geom_bar(stat = rides,width = .7, fill="steelblue"))
                     #        plotOutput("histMonthlyRiders", height = 250)
                     #   ),
                     #   
                     #   
                     # ),
                     # fluidRow(
                     #   box(title = "Monthly Riders", solidHeader = TRUE, status = "primary", width = 8,
                     #       dataTableOutput("monthlyRiderTable", height = 200)
                     #   )
                     # )
              ),
              column(6,
                     
                     uiOutput("dailyYear")
                     
                     # fluidRow(
                     #   box( title = "Daily Riders in a Year", solidHeader = TRUE, status = "primary", width = 8,
                     #        #ggplot(uicHalstedFrame, aes(x=years, y=rides)) + geom_bar(stat = "identity")
                     #        #ggplot(uicHalstedFrame, geom_bar(stat = rides,width = .7, fill="steelblue"))
                     #        plotOutput("eachDayOfYear", height = 250)
                     #   )
                     # ),
                     # box(title = "Rides per Day", solidHeader = TRUE, status = "primary", width = 8,
                     #     dataTableOutput("dailyYearlyRiderTable", height = 200)
                     # )
                     ),
              column(6,
                     
                     uiOutput("weekdays")
                     
                     # fluidRow(
                     #   box( title = "Total Entries per Year", solidHeader = TRUE, status = "primary", width = 8,
                     #        #ggplot(uicHalstedFrame, aes(x=years, y=rides)) + geom_bar(stat = "identity")
                     #        #ggplot(uicHalstedFrame, geom_bar(stat = rides,width = .7, fill="steelblue"))
                     #        plotOutput("dayOfWeek", height = 250)
                     #   )
                     # ),
                     # fluidRow(
                     #   box(title = "Weekly Rides", solidHeader = TRUE, status = "primary", width = 8,
                     #       dataTableOutput("dailyRiderTable", height = 200)
                     #   )
                     # )
                     )
              
      ),
      
      # Second tab content
      tabItem(tabName = "projInfo",
              h2("Welcome to my CS 424 Project 1"),
              h2("Created by Kevin Elliott, Spring 2022"),
              h2(""),
              h2("The data for this project was downloaded from the Chicago data portal, under the name CTA - Ridership 'L' Staion Entries - Daily Totals"),
              h2("Project is based of the starter code provided in week 2 by Professor Johnson")
              
      )
    )
  )
  )

#



# Define UI for application that draws a histogram
# ui <- fluidPage(
# 
#     # Application title
#     titlePanel("CTA Daily Ridership"),
# 
#     # Sidebar with a slider input for number of bins 
#     sidebarLayout(
#         sidebarPanel(
#             sliderInput("bins",
#                         "Number of bins:",
#                         min = 1,
#                         max = 50,
#                         value = 30)
#         ),
# 
#         # Show a plot of the generated distribution
#         mainPanel(
#            plotOutput("distPlot")
#         )
#     )
# )
#bar chart showing total entries at UIC-Halsted for each month for 2021 (jan, feb, ... dec)



# Define server logic required to draw a histogram
server <- function(input, output) {
  
  theme_set(theme_grey(base_size = 14)) 
  
  justOneYearReactive <- reactive({subset(uicHalstedFrame, year(uicHalstedFrame$date) == input$Year)})
  
  
  ## menu graph and table option reactives
  totalAcrossYearsOptionsReactive <- reactive({input$totalAcrossYears})
  #testReactive <- reactive({subset(uicHalstedFrame, year(uicHalstedFrame$date) == input$Year)})
  
  monthlyReactive <- reactive({input$monthlyYear})
  dailyYearReactive <- reactive({input$dailyYear})
  weekdaysReactive <- reactive({input$totalYear})
  
  
  
  #justOneYearReactive <- reactive({subset(uicHalstedFrame, year(uicHalstedFrame$date) == input$Year)})
  #stationReactive <- reactive({subset(allData, year(allData$newDate) == input$Stop)})
  #justOneYearReactive <- reactive({subset(rawData, year(rawData$date) == input$Year)})
  
  staticSub <- subset(uicHalstedFrame, year(uicHalstedFrame$date) == 2021)
  #View(staticSub)
  
  output$monthly <- renderUI( {
    
    monthlyInput <- monthlyReactive()
    
    if(monthlyInput == "Both"){
    
    column(10,
      fluidRow(
        box( title = "Total Rides per Month", solidHeader = TRUE, status = "primary", width = 8,
             plotOutput("histMonthlyRiders", height = 250)
        ),
      ),
      fluidRow(
        box(title = "Monthly Riders", solidHeader = TRUE, status = "primary", width = 8,
            dataTableOutput("monthlyRiderTable", height = 200)
        )
      )
    )
    }
    else if(monthlyInput == "Graph Only"){
      column(10,
             fluidRow(
               box( title = "Total Rides per Month", solidHeader = TRUE, status = "primary", width = 8,
                    plotOutput("histMonthlyRiders", height = 250)
               ),
             )
      )
    }
    else if(monthlyInput == "Table Only"){
      column(10,
             
             fluidRow(
               box(title = "Monthly Riders", solidHeader = TRUE, status = "primary", width = 8,
                   dataTableOutput("monthlyRiderTable", height = 200)
               )
             )
      )
    }
    else{
      
    }
  })
  
  output$dailyYear <- renderUI( {
    
    dailyYearInput <- dailyYearReactive()
    
    if(dailyYearInput == "Both"){
      
      column(10,
             fluidRow(
               box( title = "Daily Riders in a Year", solidHeader = TRUE, status = "primary", width = 8,
                    plotOutput("eachDayOfYear", height = 250)
               )
             ),
             box(title = "Rides per Day", solidHeader = TRUE, status = "primary", width = 8,
                 dataTableOutput("dailyYearlyRiderTable", height = 200)
             )
      )
    }
    else if(dailyYearInput == "Graph Only"){
      column(10,
             fluidRow(
               box( title = "Daily Riders in a Year", solidHeader = TRUE, status = "primary", width = 8,
                    plotOutput("eachDayOfYear", height = 250)
               )
             )
      )
    }
    else if(dailyYearInput == "Table Only"){
      column(10,
             
             fluidRow(
               box(title = "Rides per Day", solidHeader = TRUE, status = "primary", width = 8,
                   dataTableOutput("dailyYearlyRiderTable", height = 200)
               )
             )
      )
    }
    else{
      
    }
  })
  
  output$weekdays <- renderUI( {
    
    weekdaysInput <- weekdaysReactive()
    
    if(weekdaysInput == "Both"){
      
      column(10,
             fluidRow(
               box( title = "Total Entries per Year", solidHeader = TRUE, status = "primary", width = 8,
                    plotOutput("dayOfWeek", height = 250)
               )
             ),
             fluidRow(
               box(title = "Weekly Rides", solidHeader = TRUE, status = "primary", width = 8,
                   dataTableOutput("dailyRiderTable", height = 200)
               )
             )
      )
    }
    else if(weekdaysInput == "Graph Only"){
      column(10,
             fluidRow(
               box( title = "Total Entries per Year", solidHeader = TRUE, status = "primary", width = 8,
                    plotOutput("dayOfWeek", height = 250)
               )
             )
      )
    }
    else if(weekdaysInput == "Table Only"){
      column(10,
             fluidRow(
               box(title = "Weekly Rides", solidHeader = TRUE, status = "primary", width = 8,
                   dataTableOutput("dailyRiderTable", height = 200)
               )
             )
      )
    }
    else{
      
    }
  })
  
  
  # TODO - make options work for all graphs
  # move start screen graph to dashboard
  # Create table for start graph
  # make plots go right next to each other
  # stop plots from taking up space when empty
  
  
  
  
  
  

  output$histTotalYearlyRiders <- renderPlot({
    
    
    ggplot(uicHalstedFrame, aes(x=yearNumber, y=rides)) + geom_bar(stat = "identity",fill="steelblue") + 
      xlab("Year") +
      ylab("Riders") +
      ggtitle("Total Riders at UIC Halsted per Year")
    
   
    
  })
  
  output$histMonthlyRiders <- renderPlot({
    justOneYear <- justOneYearReactive()

    ggplot(justOneYear, aes(x=month(date), y=rides)) + geom_bar(stat = "identity",fill="steelblue") +
      xlab("Month") +
      ylab("Riders") +
      ggtitle("Total Monthly Riders at UIC Halsted per Year") + scale_x_continuous(breaks=c(1,2,3,4,5,6,7,8,9,10,11,12))
      #scale_x_continuous(breaks=c('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'))
  })
  
  output$eachDayOfYear <- renderPlot({
    justOneYear <- justOneYearReactive()
    ggplot(justOneYear, aes(x=date(date), y=rides)) + geom_bar(stat = "identity",fill="steelblue") +
      xlab("Day") +
      ylab("Riders") +
      ggtitle("Daily Riders per Year")
  })
  
  output$dayOfWeek <- renderPlot({
    justOneYear <- justOneYearReactive()
    
    ggplot(justOneYear, aes(x=factor(dayOfWeek, levels = dayOrder), y=rides)) + geom_bar(stat = "identity",fill="steelblue") +
      xlab("Day of Week") +
      ylab("Riders") +
      scale_y_continuous(labels = comma) + 
      ggtitle("Daily Riders per Week day")

  })
  
  output$startGraph <- renderPlot({
    
    menuChoice <-totalAcrossYearsOptionsReactive()
    
    
    if(menuChoice == "Graph"){
    ggplot(uicHalstedFrame, aes(x=yearNumber, y=rides)) + geom_bar(stat = "identity",fill="steelblue") + 
      xlab("Year") +
      ylab("Riders") +
      ggtitle("Total Riders at UIC Halsted per Year") 
    }
    else{
      ggplot(uicHalstedFrame, aes(x=yearNumber, y=rides)) + geom_bar(stat = "identity",fill="red") + 
        xlab("Year") +
        ylab("Riders") +
        ggtitle("Total Riders at UIC Halsted per Year") 
    }
    
  })
  
  # Need tables for daily riders in a year, weekday riders in a year, monthly total rides in a year
  
  # TODO - SORT BY DAY
  output$dailyRiderTable <- DT::renderDataTable(
    DT::datatable({
      justOneYear <- justOneYearReactive()
      drops <- c("station_id","stationname", "daytype", "yearNumber")
      justOneYear[ , !(names(justOneYear) %in% drops)]
      
      aggregate(justOneYear$rides, by=list(Category=justOneYear$dayOfWeek), FUN=sum)
      
    },
    
    options = list(searching = FALSE, pageLength = 4, lengthChange = FALSE, order = list(list(1, 'desc'))
    ), rownames = FALSE
    )
  )
  
  # TODO - SORT SO MONTH IS ASCENDING, ADD MONTH NAME MAYBE
  output$monthlyRiderTable <- DT::renderDataTable(
    DT::datatable({
      justOneYear <- justOneYearReactive()
      drops <- c("station_id","stationname", "daytype", "yearNumber")
      justOneYear[ , !(names(justOneYear) %in% drops)]
      
      aggregate(justOneYear$rides, by=list(Category=justOneYear$monthNumber), FUN=sum)
      
    },
    
    options = list(searching = FALSE, pageLength = 4, lengthChange = FALSE, order = list(list(1, 'desc'))
    ), rownames = FALSE
    )
  )
  
  
  
  # day by day in a whole year
  output$dailyYearlyRiderTable <- DT::renderDataTable(
    DT::datatable({
      justOneYear <- justOneYearReactive()
      drops <- c("station_id","stationname", "daytype", "yearNumber","monthNumber", "dayNumber")
      justOneYear[ , !(names(justOneYear) %in% drops)]
      
      #aggregate(justOneYear$rides, by=list(Category=date(date)), FUN=sum)
      
    },
    
    options = list(searching = FALSE, pageLength = 4, lengthChange = FALSE, order = list(list(1, 'desc'))
    ), rownames = FALSE
    )
  )
  
  # use DT to help out with the tables - https://datatables.net/reference/option/
  # output$tab1 <- DT::renderDataTable(
  #   DT::datatable({ 
  #     newNoons <-  newNoonsReactive()
  #     temperatures <- as.data.frame(table(newNoons[,input$Room], dnn = list("Temperature")), responseName = "Count")
  #   }, 
  #   options = list(searching = FALSE, pageLength = 3, lengthChange = FALSE, order = list(list(1, 'desc'))
  #   ), rownames = FALSE 
  #   )
  # )

    # output$distPlot <- renderPlot({
    #     # generate bins based on input$bins from ui.R
    #     x    <- faithful[, 2]
    #     bins <- seq(min(x), max(x), length.out = input$bins + 1)
    # 
    #     # draw the histogram with the specified number of bins
    #     hist(x, breaks = bins, col = 'darkgray', border = 'white')
    # })
} 

#ggplot(uicHalstedFrame, geom_bar(stat = "rides",width = .7, fill="steelblue"))

# ggplot functions




# output$hist0 <- renderPlot({
#   ggplot(years, aes(x=year(uicHalstedFrame$date), y=uicHalstedFrame$rides)) +
#     labs(x=paste("Year", years), y = "Ridership") + geom_point(alpha = 1/12) + ylim(55,90) +
#     scale_x_date(date_breaks = "1 Year", date_labels =  "%b", expand = c(0, 0))
# })

# Run the application 
shinyApp(ui = ui, server = server)

